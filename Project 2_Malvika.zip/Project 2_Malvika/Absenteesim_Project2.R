# Clean the environment
rm(list = ls())

# Set working directory
setwd("C:/Malvika/Edwisor/Edwisor/Project/Project 2_Malvika")

# Checking working directory set correctly
getwd()

# Load libraries"
x = c("readxl","dplyr","DMwR","ggplot2","gridExtra","lubridate","geosphere","usdm","corrgram","rpart"
      ,"MASS","randomForest","inTrees", "dummies" , "mlr", "propagate")
install.packages(x)
lapply(x, require, character.only = TRUE)
rm(x)


# laod the data 

Train_data = read_xls("Absenteeism_at_work_Project.xls")


######################### Exploratory Data Analysis #############################

# Data info
str(Train_data)
summary(Train_data)
class(Train_data)
dim(Train_data) # 740 Observation & 21 Variable

# Changing the variable names to remove space from between the variable naming

names(Train_data)[2]="Reason_for_absence"
names(Train_data)[3] = "Month_of_absence"
names(Train_data)[4] = "Day_of_the_week"
names(Train_data)[6] = "Transportation_expense"
names(Train_data)[7] = "Distance_from_Residence_to_Work"
names(Train_data)[8] = "Service_time"
names(Train_data)[10] = "Work_load_Average_day"
names(Train_data)[11] = "Hit_target"
names(Train_data)[12] = "Disciplinary_failure"
names(Train_data)[15] = "Social_drinker"
names(Train_data)[16] = "Social_smoker"
names(Train_data)[20] = "Body_mass_index"
names(Train_data)[21] = "Absenteeism_time_in_hours"

#since month variable can contain maximum 12 values, so here replace 0 with NA

Train_data$Month_of_absence[Train_data$Month_of_absence %in% 0]= NA

# From the problem statement categorising data in 2 category "continuous" and "catagorical"

continuous_vars = c('Distance_from_Residence_to_Work', 'Service_time', 'Age',
                    'Work_load_Average_day', 'Transportation_expense',
                    'Hit_target', 'Weight', 'Height', 
                    'Body_mass_index', 'Absenteeism_time_in_hours')

catagorical_vars = c('ID','Reason_for_absence','Month_of_absence','Day_of_the_week',
                     'Seasons','Disciplinary_failure', 'Education', 'Social_drinker',
                     'Social_smoker', 'Son', 'Pet')



#convert to proper type

Train_data=as.data.frame(Train_data)

# Converting categorical variable into data frames

Train_data$Reason_for_absence=as.factor(Train_data$Reason_for_absence)
Train_data$Month_of_absence=as.factor(Train_data$Month_of_absence)
Train_data$Day_of_the_week=as.factor(Train_data$Day_of_the_week)
Train_data$Seasons=as.factor(Train_data$Seasons)
Train_data$Disciplinary_failure=as.factor(Train_data$Disciplinary_failure)
Train_data$Education=as.factor(Train_data$Education)
Train_data$Social_drinker=as.factor(Train_data$Social_drinker)
Train_data$Social_smoker=as.factor(Train_data$Social_smoker)

str(Train_data)

#**********************Data Pre-processing****************************#

################## Missing Values Analysis ###################


sum(is.na(Train_data)) ## 138 Missing values



#Creating a dataframe with missing values present in each variable
missing_val = data.frame(apply(Train_data,2,function(x){sum(is.na(x))}))
missing_val$Columns = row.names(missing_val)
names(missing_val)[1] =  "Missing_percentage"

#Calculating percentage missing value
missing_val$Missing_percentage = (missing_val$Missing_percentage/nrow(Train_data)) * 100

# Sorting missing_val in Descending order
missing_val = missing_val[order(-missing_val$Missing_percentage),]
row.names(missing_val) = NULL

# Reordering columns
missing_val = missing_val[,c(2,1)]

#Missing value imputation for categorical variables-
#Mode method-
mode=function(v){
  uniqv=unique(v)
  uniqv[which.max(tabulate(match(v,uniqv)))]
}

for(i in catagorical_vars){
  print(i)
  Train_data[,i][is.na(Train_data[,i])] = mode(Train_data[,i])
}

#Now check the remaining missing values-
sum(is.na(Train_data))  ##missing values= 100

## Missing value is < 30% so will impute instead of dropping
##Choise which method is suitable for imputation

#Train_data[4,20] ## Original value = 24
#Train_data[4,20] = NA
#Train_data[4,20]

# Actual Value = 24
# Mean = 26.7
# Median = 25
# KNN = 24.4


#Mean Method
#Train_data$Body_mass_index[is.na(Train_data$Body_mass_index)] = mean(Train_data$Body_mass_index, na.rm = T)
#Train_data[4,20] # Mean = 26.7


#Median Method for Continous variable
#Train_data$Body_mass_index[is.na(Train_data$Body_mass_index)] = median(Train_data$Body_mass_index, na.rm = T)
#Train_data[4,20] # Mean = 25

# kNN Imputation
Train_data = knnImputation(Train_data,k=3)
#Train_data[4,20] # 24.4


# Checking for missing value
sum(is.na(Train_data)) ## O Missing value

#################### Outlier Analysis #####################

#Detecting Outlier Analysis

# Boxplot for continuous variables
for (i in 1:length(continuous_vars))
{
  assign(paste0("gn",i), ggplot(aes_string(y = (continuous_vars[i]), x = "Absenteeism_time_in_hours"), data = subset(Train_data))+ 
           stat_boxplot(geom = "errorbar", width = 0.5) +
           geom_boxplot(outlier.colour="red", fill = "grey" ,outlier.shape=18,
                        outlier.size=1, notch=FALSE) +
           theme(legend.position="bottom")+
           labs(y=continuous_vars[i],x="Absenteeism_time_in_hours")+
           ggtitle(paste("Box plot of absenteeism for",continuous_vars[i])))
}

### Plotting plots together
gridExtra::grid.arrange(gn1,gn2,gn3,gn4,gn5,gn6,gn7,gn8,gn9,gn10 ,ncol=3, nrow=4)


##Remove outliers using boxplot method

##loop to remove from all variables
for(i in continuous_vars)
{
  print(i)
  val = Train_data[,i][Train_data[,i] %in% boxplot.stats(Train_data[,i])$out]
  #print(length(val))
  Train_data = Train_data[which(!Train_data[,i] %in% val),]
}

#Replace all outliers with NA and impute

for(i in continuous_vars)
{
  val = Train_data[,i][Train_data[,i] %in% boxplot.stats(Train_data[,i])$out]
  #print(length(val))
  Train_data[,i][Train_data[,i] %in% val] = NA
}

# Imputing missing values
Train_data = knnImputation(Train_data,k=3)

sum(is.na(Train_data)) ## 0 NA

################ Feature Selection ################

#correlation plot for Continuous_vars

corrgram(Train_data[,continuous_vars],order = F,upper.panel = panel.pie,text.panel = panel.txt,
         main="Correlation plot")

## ANOVA test for Categorical variable
summary(aov(formula = Absenteeism_time_in_hours~ID,data = Train_data))
summary(aov(formula = Absenteeism_time_in_hours~Reason_for_absence,data = Train_data))
summary(aov(formula = Absenteeism_time_in_hours~Month_of_absence,data = Train_data))
summary(aov(formula = Absenteeism_time_in_hours~Day_of_the_week,data = Train_data))
summary(aov(formula = Absenteeism_time_in_hours~Seasons,data = Train_data))
summary(aov(formula = Absenteeism_time_in_hours~Disciplinary_failure,data = Train_data))
summary(aov(formula = Absenteeism_time_in_hours~Education,data = Train_data))
summary(aov(formula = Absenteeism_time_in_hours~Social_drinker,data = Train_data))
summary(aov(formula = Absenteeism_time_in_hours~Social_smoker,data = Train_data))
summary(aov(formula = Absenteeism_time_in_hours~Son,data = Train_data))
summary(aov(formula = Absenteeism_time_in_hours~Pet,data = Train_data))

## Dimension Reduction
Train_data = subset(Train_data, select = -c(Weight, Day_of_the_week,Pet,Social_smoker,Education,
                                            Seasons))
dim(Train_data) ## 545 Onservation & 15 Variable

############# Feature Scaling ##############

# Updating the continuous and catagorical variable

continuous_vars = c('Distance_from_Residence_to_Work', 'Service_time', 'Age','Work_load_Average_day',
                    'Transportation_expense', 'Hit_target', 'Height','Body_mass_index')

catagorical_vars = c('ID','Reason_for_absence','Month_of_absence','Disciplinary_failure',
                     'Social_drinker','Son')


#Skewness of numeric variables-


for(i in continuous_vars){
  skew = skewness(Train_data[,i])
  print(i)
  print(skew)
}

#log transform
Train_data$Absenteeism_time_in_hours = log1p(Train_data$Absenteeism_time_in_hours)

#Normality check
hist(Train_data$Absenteeism_time_in_hours)


# Normalization
for(i in continuous_vars)
{
  print(i)
  Train_data[,i] = (Train_data[,i] - min(Train_data[,i]))/(max(Train_data[,i])-min(Train_data[,i]))
}

############ Sampling Technique ###############


catagorical_vars = c('ID','Reason_for_absence','Month_of_absence','Disciplinary_failure',
                     'Social_drinker','Son')

#create dummy variable for categorical variables-

Train_data = dummy.data.frame(Train_data, catagorical_vars)

dim(Train_data) ## 545 Observation & 82 Variable

#Divide data into train and test using stratified sampling method
set.seed(6789)
Train.index = sample(1:nrow(Train_data), 0.8 * nrow(Train_data))
Train = Train_data[ Train.index,]
Test  = Train_data[-Train.index,]

#  ******* Error Metrix function defining***********

RMSE = function(actual, predict)
{
  sqrt(sum((predict - actual)^2) / nrow(Train_data))
}


# ************************** Modeling ******************************

# Decision Tree

DT_model = rpart(Absenteeism_time_in_hours ~.,data = Train,method = "anova")
summary(DT_model)
pred_DT = predict(DT_model,Test[,-82])


RMSE(Test[,-82], pred_DT)## 5.686


#   ***************Random Forest*****************
# Random forest with 500 Trees
RF_model = randomForest(Absenteeism_time_in_hours ~. ,data = Train, ntree = 500)

pred_RF = predict(RF_model, Test[,-82])
print(RF_model)


RMSE(Test[,-82], pred_RF) ## 5.61

# Random forest with 1000 Trees

RF_model1 = randomForest(Absenteeism_time_in_hours ~. ,data = Train, ntree = 1000)

pred_RF1 = predict(RF_model1, Test[,-82])
print(RF_model1)


RMSE(Test[,-82], pred_RF1) ## 5.60

#Building Linear Regression Model
#Check for multi-collinearity

continuous_vars = c('Distance_from_Residence_to_Work', 'Service_time', 'Age','Work_load_Average_day',
                    'Transportation_expense', 'Hit_target', 'Height','Body_mass_index')

numeric_data= Train_data[,continuous_vars]
cnames = colnames(numeric_data)
cnames

# VIF(Variance Infleation factor)
vif(numeric_data)
vifcor(numeric_data,th=0.7)

LR_model = lm(Absenteeism_time_in_hours ~.,data = Train)
summary(LR_model)


pred_LR = predict(LR_model,Test[,-82])

RMSE(Test[,-82], pred_LR) ## 5.64




