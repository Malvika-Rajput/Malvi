## Clean the environment
rm(list = ls())

## Set working directory
setwd("C:/Malvika/Edwisor/Edwisor/Project/Project 1_Malvika")

## Checking working directory set correctly
getwd()


## Load libraries"
x = c("dplyr","DMwR","ggplot2","gridExtra","lubridate","geosphere","usdm","corrgram","rpart","MASS",
      "randomForest","inTrees")
install.packages(x)
lapply(x, require, character.only = TRUE)
rm(x)

## laod the data 

Train_data = read.csv("train_cab.csv" , header = T, na.strings = c(" ", "", NA))  ## 7 vairables and 16067 observation in Train data


## Structure of data
str(Train_data)
summary(Train_data)

sum(is.na(Train_data)) ## 79 Missing values 

######################### Exploratory Data Analysis #############################

## Convert data into proper data type
Train_data$fare_amount = as.numeric(as.character(Train_data$fare_amount))
Train_data$passenger_count = as.integer(as.character(Train_data$passenger_count))

##### Converting our Pickup time variable into data time for Train Data *******

# Convert into charater

Train_data$pickup_datetime = as.character(Train_data$pickup_datetime)

#converting into date & time

Train_data$pickup_datetime = as.POSIXct(Train_data$pickup_datetime, format = "%Y-%m-%d %H:%M:%S", tz = "")
Train_data$Hours = as.numeric(format(as.POSIXct(strptime(Train_data$pickup_datetime, "%Y-%m-%d %H:%M:%S", tz = "")) ,format = "%H"))
Train_data$Minutes = as.numeric(format(as.POSIXct(strptime(Train_data$pickup_datetime, "%Y-%m-%d %H:%M:%S", tz = "")) , format = "%M"))
Train_data$Date =  as.numeric(format(as.POSIXct(strptime(Train_data$pickup_datetime, "%Y-%m-%d %H:%M:%S", tz = "")) , format = "%d"))
Train_data$Month =  as.numeric(format(as.POSIXct(strptime(Train_data$pickup_datetime, "%Y-%m-%d %H:%M:%S", tz = "")) , format = "%m"))
Train_data$Year = as.numeric(format(as.POSIXct(strptime(Train_data$pickup_datetime, "%Y-%m-%d %H:%M:%S", tz = "")) , format = "%Y"))

# Remove NA
sum(is.na(Train_data)) ## Now missing values are 86
str(Train_data)


######################## Data Preprocessing ####################

# *************** Missing Value Analysis *************************

# create data frame with missing percentage
Train_data1 = data.frame(apply(Train_data, 2,function(x){sum(is.na(x))}))

## Convert rows into Column
Train_data1$Columns = row.names(Train_data1)
row.names(Train_data1) = NULL

## Remane variable 
names(Train_data1)[1] = "Missing %age"

## Calculate Percentage
Train_data1$`Missing %age`= (Train_data1$`Missing %age`/nrow(Train_data)) * 100

##Arrange in decending order
Train_data1 = Train_data1[order(-Train_data1$`Missing %age`),]

## Missing value is < 30% for both Fare_amount, Passenger_count & Pickup datetime so will impute instead of dropping
##Choise which method is suitable for imputation

#Train_data[24,1] ## Original value =4.9
#Train_data[24,1] = NA
#Train_data[24,1]

## Summary of the method
## Mean = 15.01 
## Median for Fare_amount = 8.5 Will use Median method for imputing missing value
## KNN imputation = 9.28 

## Mean Method
##Train_data$fare_amount[is.na(Train_data$fare_amount)] = mean(Train_data$fare_amount, na.rm = 1)
##Train_data[24,1]

## Median Method
Train_data$fare_amount[is.na(Train_data$fare_amount)] = median(Train_data$fare_amount, na.rm = 1)
Train_data$passenger_count[is.na(Train_data$passenger_count)] = median(Train_data$passenger_count, na.rm = 1)
Train_data$pickup_datetime[is.na(Train_data$pickup_datetime)] = median(Train_data$pickup_datetime, na.rm = 1)
Train_data$Hours[is.na(Train_data$Hours)] = median(Train_data$Hours, na.rm = 1)
Train_data$Minutes[is.na(Train_data$Minutes)] = median(Train_data$Minutes, na.rm = 1)
Train_data$Year[is.na(Train_data$Year)] = median(Train_data$Year, na.rm = 1)
Train_data$Month[is.na(Train_data$Month)] = median(Train_data$Month, na.rm = 1)
Train_data$Date[is.na(Train_data$Date)] = median(Train_data$Date, na.rm = 1)
##Train_data[24,1]

## KNN imputation method
#Train_data = knnImputation(Train_data, k = 5) 
##Train_data[24,1]

#Check if any missing values
sum(is.na(Train_data))

# ****** Will calculate Distance between the pick up & drop Location ***********


Train_data = subset(Train_data, (pickup_longitude < 180 & pickup_longitude > -180))
Train_data = subset(Train_data, (pickup_latitude < 90 & pickup_latitude > -90))
Train_data = subset(Train_data, (dropoff_latitude < 90 & dropoff_latitude > -90))
Train_data = subset(Train_data, (dropoff_longitude < 180 & dropoff_longitude > -180))


#Will remove these values (0.00000,0.00000) from Lat/Long of pickup & drop

Train_data = subset(Train_data,(pickup_longitude != 0.00000 & pickup_longitude != 0.00000))
Train_data = subset(Train_data,(dropoff_longitude != 0.00000 & dropoff_longitude != 0.00000))

#Using Haversine Function of Geosphere package

Train_data$Distance =  distHaversine(cbind(Train_data$pickup_longitude, Train_data$pickup_latitude),
                                     cbind(Train_data$dropoff_longitude, Train_data$dropoff_latitude))
Train_data[order(-Train_data$Distance), ]


#*************************** Outlier Analysis ***************************

numeric_index = sapply(Train_data, is.numeric) # creating numerical value index
numeric_data = Train_data[,numeric_index] # storing numeric data
cnames = colnames(numeric_data) #storing numeric data column names
summary(numeric_data)
#Creating box-plot to analyze outliers
for (i in 1:length(cnames)){
  assign(paste0("gn",i), ggplot(aes_string(y = (cnames[i]), x = "fare_amount"), data = subset(Train_data)) +
           stat_boxplot(geom = "errorbar", width = 0.5) + 
           geom_boxplot(outlier.colour = "red", fill = "blue", outlier.shape = 18, outlier.size = 1, notch = FALSE) + 
           theme(legend.position = "bottom") + labs(y = cnames[i], x="fare") + ggtitle(paste("Box Plot of fare for", cnames[i])))
}
gridExtra::grid.arrange(gn2, gn3, ncol = 2)
gridExtra::grid.arrange(gn4, gn5, ncol = 2)
gridExtra::grid.arrange(gn6, gn12, ncol =2)
gridExtra::grid.arrange(gn7, gn8, gn9, gn10, gn11, ncol = 2 ,nrow =3) # exclude if gn1 as that is unique for each observation

#Loop to remove outliers from all variable 

for(i in cnames) {
  print(i)
  val = Train_data[,i][Train_data[,i] %in% boxplot.stats(Train_data[,i]) $out]
  
  print(length(val))
  Train_data[,i][Train_data[,i] %in% val] = NA
}

sum(is.na(Train_data))
Train_data=na.omit(Train_data)
summary(Train_data)

##################################Feature Selection################################################

#A. Correlation check on continuous variable

corrgram(Train_data[, numeric_index], order = F, upper.panel = panel.pie, text.panel = panel.txt, main = "correlation plot") 

## Dimension Reduction
Train_data = subset(Train_data,select = -c(pickup_datetime))



##################################Feature Scaling################################################
#Normality check
qqnorm(Train_data$fare_amount, pch = 1, frame = FALSE)
qqline(Train_data$fare_amount, col = "Green", lwd = 2)

qqnorm(Train_data$Distance, pch = 1, frame = FALSE)
qqline(Train_data$Distance, col = "Green", lwd = 2)

hist(Train_data$fare_amount)
hist(Train_data$Distance)

# data is left Skewed so we go for Normalization
#Normalisation for Train Data
cnames = c("Distance","fare_amount","passenger_count","pickup_latitude","pickup_longitude","dropoff_latitude",
           "dropoff_longitude","Date","Month","Year","Hours","Minutes")

for(i in cnames){
  print(i)
  Train_data[,i] = (Train_data[,i] - min(Train_data[,i]))/
    (max(Train_data[,i] - min(Train_data[,i])))
}


################### Model development ###############

set.seed(1234)
Train_index = sample(1:nrow(Train_data), 0.8*nrow(Train_data))
data_train = Train_data[Train_index,] 
data_test = Train_data[-Train_index,]

data_train= subset(Train_data, select = c(1,6:12))

#  ******* Error Metrix function defining***********
#1. Calculate MAPE

MAPE = function(actual, predict)
{
  mean(abs((actual-predict)/actual))*100
}
#2. Calculate RMSE

RMSE = function(actual, predict)
{
  sqrt(sum((predict - actual)^2) / nrow(Train_data))
}
#3. Calculate MSE
MSE = function(actual, predict)
{
  sqrt(sum((predict - actual)^2) / nrow(Train_data)) / mean(actual)
}


#1. ************* Linear Regression Model************* 

# Multicollinearity check

vifcor(data_train[,-1], th = 0.9) ## No collinearity in the data

lm_model = lm(fare_amount ~., data = data_train)
summary(lm_model)

prediction_LRM = predict(lm_model, data_test[,2:12])


 
MAPE(data_test[,1], prediction_LRM) ## 13.625
RMSE(data_test[,1], prediction_LRM) ## 0.037
MSE(data_test[,1], prediction_LRM) ## 0.083
#   R-Square = 0.685 & Adjusted R-Square = 0.685

# *************Decision Tree************************

DT_Model = rpart(fare_amount ~., data = data_train, method = "anova")
summary(DT_Model)


dev.new()
plot(DT_Model)
text(DT_Model)
summary(DT_Model)
printcp(DT_Model)

prediction_DT = predict(DT_Model, data_test[,2:12])

MAPE(data_test[,1], prediction_DT) ## 14.374
RMSE(data_test[,1], prediction_DT) ## 0.039
MSE(data_test[,1], prediction_DT) ## 0.087

# *******************Random Forst ***************

#model
model_RF = randomForest(fare_amount ~. , data_train, importance = TRUE, ntree = 500)

#Error plotting
plot(model_RF) #my error i decreasing with higher number of trees

# Checking model by predicting on out of sample data
prediction_RF = predict(model_RF, data_test[,2:12])
print(model_RF)

MAPE(data_test[,1], prediction_RF) #6.592
RMSE(data_test[,1], prediction_RF) #0.018
MSE(data_test[,1], prediction_RF) #0.040
#Mean of squared residuals: 0.00684
#% Var explained: 70.95

model_RF1 = randomForest(fare_amount ~. , data_train, importance = TRUE, ntree = 100)

#Error plotting
plot(model_RF1) #my error i decreasing with higher number of trees

# Checking model by predicting on out of sample data
predictRF1 = predict(model_RF1, data_test[,2:12])
print(model_RF1)

MAPE(data_test[,1], predictRF1) #6.642
RMSE(data_test[,1], predictRF1) #0.0186
MSE(data_test[,1], predictRF1) #0.0412
#Mean of squared residuals: 0.0070
#% Var explained: 70.1


plot(data_test[,1], prediction_LRM, xlab = 'Actual values', ylab = 'Predicted values', main = 'Multilinear')
plot(data_test[,1], prediction_DT, xlab = 'Actual values', ylab = 'Predicted values', main = 'Decision Tree')
plot(data_test[,1], prediction_RF, xlab = 'Actual values', ylab = 'Predicted values', main = 'Random forest(n=500)') 
plot(data_test[,1], predictRF1, xlab = 'Actual values', ylab = 'Predicted values', main = 'Random forest(n=100)') 

#===========Predicting for Test Data========================#

## laod the Test data
Test_data_Final = read.csv("test.csv" , header = T)  ## 6 variable and 9914 observation 
 
## Structure of Test data
str(Test_data_Final)
summary(Test_data_Final)

######################### Exploratory Data Analysis #############################
#converting pickup datetime into date & time

Test_data_Final$pickup_datetime = as.POSIXct(Test_data_Final$pickup_datetime, format = "%Y-%m-%d %H:%M:%S", tz = "")
Test_data_Final$Hours = as.numeric(format(as.POSIXct(strptime(Test_data_Final$pickup_datetime, "%Y-%m-%d %H:%M:%S", tz = "")) ,format = "%H"))
Test_data_Final$Minutes = as.numeric(format(as.POSIXct(strptime(Test_data_Final$pickup_datetime, "%Y-%m-%d %H:%M:%S", tz = "")) , format = "%M"))
Test_data_Final$Date =  as.numeric(format(as.POSIXct(strptime(Test_data_Final$pickup_datetime, "%Y-%m-%d %H:%M:%S", tz = "")) , format = "%d"))
Test_data_Final$Month =  as.numeric(format(as.POSIXct(strptime(Test_data_Final$pickup_datetime, "%Y-%m-%d %H:%M:%S", tz = "")) , format = "%m"))
Test_data_Final$Year = as.numeric(format(as.POSIXct(strptime(Test_data_Final$pickup_datetime, "%Y-%m-%d %H:%M:%S", tz = "")) , format = "%Y"))

# Remove NA
##sum(is.na(Test_data_Final)) ## No NA in the data

# ****** Will calculate Distance between the pick up & drop Location ***********


Test_data_Final = subset(Test_data_Final, (pickup_longitude < 180 & pickup_longitude > -180))
Test_data_Final = subset(Test_data_Final, (pickup_latitude < 90 & pickup_latitude > -90))
Test_data_Final = subset(Test_data_Final, (dropoff_latitude < 90 & dropoff_latitude > -90))
Test_data_Final = subset(Test_data_Final, (dropoff_longitude < 180 & dropoff_longitude > -180))


#Will remove these values (0.00000,0.00000) from Lat/Long of pickup & drop

Test_data_Final = subset(Test_data_Final,(pickup_longitude != 0.00000 & pickup_longitude != 0.00000))
Test_data_Final = subset(Test_data_Final,(dropoff_longitude != 0.00000 & dropoff_longitude != 0.00000))

#Using Haversine Function of Geosphere package

Test_data_Final$Distance =  distHaversine(cbind(Test_data_Final$pickup_longitude, Test_data_Final$pickup_latitude),
                                     cbind(Test_data_Final$dropoff_longitude, Test_data_Final$dropoff_latitude))
Test_data_Final[order(-Test_data_Final$Distance), ]

str(Test_data_Final)

Test_data_Final = subset(Test_data_Final, select = c(6:12))

#Normality check
hist(Test_data_Final$Distance)
hist(Test_data_Final$passenger_count)

# data is left Skewed so we go for Normalization
#Normalisation for Test Data
cnames = c("Distance","passenger_count","Date","Month","Year","Hours","Minutes")

for(i in cnames){
  print(i)
  Test_data_Final[,i] = (Test_data_Final[,i] - min(Test_data_Final[,i]))/
    (max(Test_data_Final[,i] - min(Test_data_Final[,i])))
}


predictRF_test = predict(model_RF, Test_data_Final)
Test_data_Final$fare_amount = predictRF_test

write.csv(Test_data_Final, "Final test data in R.csv", row.names = F)


#PLoting the graph for distance and Fare
gplot = ggplot(data=Test_data_Final, aes(x=Distance, y=fare_amount)) + geom_point()+ geom_line()+ 
  ggtitle("Distance and Fare Plot") + xlab("Distance in KM ") +   ylab("Fare")
gplot


#----------------------------End of the project-------------------------------------#